//Problem 2: If a person is allowed to drive in India print "Apply for a license" or "NA".

let age=19;
if(age>=18){
  console.log("Apply for a licence");
}else{
  console.log("NA")
}