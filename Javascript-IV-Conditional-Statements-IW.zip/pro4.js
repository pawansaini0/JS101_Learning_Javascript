//Problem 4: Given stored username and password and input username and password, Print if the user can login or not.

let StoredUserName= "amankumar12";
let StoredPassword="aman@123";

let InputUserName="amankumar12";
let InputPasword="aman@123";
if(StoredUserName==InputUserName&&StoredPassword==InputPasword){
  console.log("logged in")
}else{
  console.log("Try again")
}