//Problem 1: If the number is divisible by 3, print a "multiple of 3".

let num=12;
if(num%3==0){
  console.log(num);
}